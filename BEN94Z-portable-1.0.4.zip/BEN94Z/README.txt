BEN94Z  -  audio-reactive 3D music visualizer and screensaver
==============================================================

Controls
  Enter        automatic scene switching on/off. It follows the music, changes scene every 30-75 s,
               and makes sure every scene gets its turn (a scene that has not been shown for a while
               is favoured). With no audio playing it simply rotates through all of them.
               The three forest scenes (Fire, Firefly Forest, Cyber Firefly) get a standing preference,
               so every screensaver run includes one.
               The screensaver opens on a random scene; "ben94z-screensaver log" lists the scenes shown.
  0-9, K       pick a scene: 0 Toxic, 1 Synthwave, 2 Beat Sync, 3 Rainbow Crystal, 4 Iron Man,
               5 Snow, 6 Matrix, 7 Fire, 8 Ocean, 9 Firefly Forest, K Cyber Firefly
  Q            ECO / DETAIL (always starts in DETAIL and stays there until you press Q)
  [ and ]      how strongly the visuals react
  + and -      audio sensitivity
  Space        automatic camera on/off
  F11          show / hide the on-screen information
  F12          fullscreen
  Esc          quit

Screensaver mode
  BEN94Z --screensaver     fullscreen, no HUD, exits when the keyboard or mouse is used.
  (Windows also accepts /s. /p and /c exit immediately.)

Choosing the audio source
  Linux    listens to the default input. To visualize what the computer is playing, set
           Settings > Sound > Input to "Monitor of ...", or start with
             BEN94Z_AUDIO_DEVICE=monitor BEN94Z
  Windows  captures what the PC is playing (loopback) by default.
           Set BEN94Z_MIC=1 to use the microphone instead.
  Demo     BEN94Z_DEMO=1 plays a built-in test track so you can preview without any audio.

Other settings (environment variables, or lines in the settings file on Windows and Linux:
  ~/.config/ben94z/config.txt)
  BEN94Z_FPS=30            frame-rate target (15-60)
  BEN94Z_SCENE_SECS=30     minimum seconds per scene in automatic mode
  BEN94Z_ECO=1             start in ECO instead of DETAIL (lighter on slow graphics)
  BEN94Z_AUTO_ECO=1        drop to ECO automatically if frames stay slow (off by default)

Linux idle screensaver (GNOME, Wayland or X11)
  ben94z-screensaver enable [SECONDS]   start BEN94Z after that much idle time (default 300)
  ben94z-screensaver disable
  ben94z-screensaver status
  ben94z-screensaver test
  It never starts while the session is locked or while a video is inhibiting idle, and it does
  not touch GNOME's lock screen. In GNOME Settings > Power, set Screen Blank to a longer time
  than the BEN94Z delay (or Never), otherwise the screen blanks before BEN94Z appears.
  Use only one idle launcher at a time: if you already have your own, do not enable this one.

Windows screensaver
  The installer has an optional "Windows screensaver" component. Afterwards either use the Start menu
  shortcut "Set BEN94Z as my screen saver", or choose it under
  Settings > Personalization > Lock screen > Screen saver settings.
  The "Settings..." button there (or the Start menu shortcut "BEN94Z settings") opens the settings
  file in Notepad: %APPDATA%\BEN94Z\config.txt. Remove the # in front of a line, save, and it applies
  the next time the screensaver starts. On Windows BEN94Z captures what the PC is playing; set
  BEN94Z_MIC=1 in that file to use the microphone instead.
  If something stops early, the log is at %LOCALAPPDATA%\BEN94Z\screensaver.log.
  Windows may show a "Windows protected your PC" (SmartScreen) notice because the program is not
  code-signed: choose "More info", then "Run anyway".
  Only the main display is used on multi-monitor setups.
